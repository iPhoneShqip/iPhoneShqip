local M_PI = 3.14159265
--this code could use some improving...
return function (view, height, percent, is_inside)
    local angle = percent*M_PI
    local m = is_inside and 1/3 or -2/3

    local y = height/2
    if percent < 0 then y = -y end

    view:translate(0, y, 0)
    view:rotate(m*angle, 0, 1, 0)
    view:translate(0, -y, 0)
end
