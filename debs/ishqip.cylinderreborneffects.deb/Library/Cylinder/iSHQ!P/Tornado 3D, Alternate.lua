--[[ ******************************************************************
Sphere by KnifeOfPi
/u/rweichler, I expect my T-shirt!
		
******************************************************************* ]]
-- my apologies for the illegible code
return function(pg, of, sw, sh)

	pg:translate(of,0,0)

    local pc, cx, cy, ops = math.abs(of/pg.width), pg.width/2, pg.height/2, of/pg.width
	-- target distance
local midx =pg.width/2

	local midy =pg.height/2+7
	local tg = pg.width
	local fx = pc*5
	if fx>1 then fx=1 end
local side = -1

	-- if(of>0) then side=1 end
    for i, ic in subviews(pg) do
		-- get icon center
		local icx, icy = (ic.x+ic.width/2), (ic.y+ic.height/2)
		-- get icon offset from page center
		local ox, oy = cx-icx, cy-icy
		-- get angle of icon position
		local ang = math.atan2(oy,ox)
		-- get hypotenuse
		local h = math.sqrt( ox^2+oy^2)
		
local iconX = ic.x+ic.width/2
		local fall = (1-pc^2)*h
	  local iconY = ic.y+ic.height/2
		-- get hypotenuse extension
		local nh = math.sqrt((iconX-midx)^2+(iconY-midy)^2)
		local oh = fx*h+fx*tg
		-- directions
		local dx, dy, dxz, dyz = 1,1,1,1
		if icx<cx then dx=0 dxz=1 end
		if icx>cx then dx=-1 dxz=-1 end
		if icy<cy then dy=0 dyz=1 end
		if icy>cy then dy=-1 dyz=-1 end
		if icy==cy then dy=1 end
		local nx = 0
local ny = 0
		-- calc new x & y
		-- local nx = math.sqrt(h^2-oy^2)
		-- local ny = math.sqrt(h^2-ox^2)
		nx = 0
		ny =0-h*math.sin(230/(h+50)*ops*2*math.pi+ang)
		local size=(3-fx)*(fall/h)
		if size>1 then size=1 end
		local w = pc-math.abs(ox/300)
		if w<0 then w=0 end
local x=(pc-0.2)*5/4
if x<0 then x=0 end
local ry = oy
		-- move!
		-- print(ox)
		-- if fx<1 then ic:translate((fx)*ox, 0, 0) end
ic:translate(fx*ox, 0)
		ic:rotate(ops*3*math.pi-fx*(1.6*ox/pg.width)*.8*math.pi, 0, 1, 0)

		if fx<=10 then ic:translate(fx*.45*-2.75*math.abs((oy+(.5*pg.height))/40)^2, 0, 0) end
ic:rotate(fx*.5*math.pi, 0, 1, 0)
ic:rotate(fx*.17*math.pi, 1, 0, 0)
-- ic:rotate(.5*math.pi, 0, 1, 0)
-- viewFlip(pg, pc, 1, true)
-- ic:scale(size*size)
-- ic:translate(-0.5*nx,-0.5*ny,0)
		
		-- if pc>0.6 then
			ic.alpha = 1-pc
		-- end

    end
end

