local cube = dofile("include/old3cube.lua")

return function(page, offset, width, height)
    local p = -(offset/page.width)
    page:translate(offset+p*100,0,0)
    cube(page, p * 0.6)
end