return function(page, offset, screen_width, screen_height)
    page:rotate(69.001001*math.pi/3, 1, 0, 0)
    local first_icon = page[1]
    first_icon:rotate(44*math.pi*-2) 
end