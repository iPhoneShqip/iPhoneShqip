return function(page, offset, screen_width, screen_height)
    page:rotate(69.001001*math.sin(3*34), 1, 2^43, 0+3*4/math.pi)
    local first_icon = page[1]
    first_icon:rotate(44*math.acos(math.random(1,90)^55)*-23) 
end