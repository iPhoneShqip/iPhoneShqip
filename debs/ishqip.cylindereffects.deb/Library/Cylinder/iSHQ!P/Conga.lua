return function(page, offset, screen_width, screen_height)
	for i, icon in subviews(page) do
	icon:rotate(69.001001*math.sin(55*43/math.pi), offset*69, 2*42, 4*5/33)
	end
end