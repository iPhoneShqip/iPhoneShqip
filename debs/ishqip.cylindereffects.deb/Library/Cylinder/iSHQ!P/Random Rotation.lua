--[[ ******************************************************************
Concave Central Turn - modified Explosion by KnifeOfPi
******************************************************************* ]]
local animations = {}
for i=1,24,1 do
        animations[i] = 0
end
local a2 = {}
for i=1,24,1 do
        a2[i] = 0
end

local a3 = {}
for i=1,24,1 do
        a3[i] = 0
end
return function(pg, of, sw, sh)

        -- pg:translate(of,0,0)

    local pc, cx, cy = math.abs(of/pg.width), pg.width/2, pg.height/2
        -- target distance
        local tg = pg.width
        local fnum=1;
        -- local rand = math.random(-100, 100)
    for i, ic in subviews(pg) do
local did = math.random(-10, 10)
                -- rand = rand + did
local rand = math.random(-100, 100)
local a = 1

if pc<=0.001 then for i=1,24,1 do
        animations[i] = math.random(-100, 100)
end
end
if pc<=0.001 then for i=1,24,1 do
        a2[i] = math.random(-100, 100)
end
end
if pc<=0.0010 then for i=1,24,1 do
        a3[i] = math.random(-100, 100)
end
end
                
                
                -- get icon center
                local icx, icy = (ic.x+ic.width/2), (ic.y+ic.height/2)
                -- get icon offset from page center
                local ox, oy = cx-icx, cy-icy
                -- get angle of icon position
                local ang = math.atan(oy/ox)
                -- get hypotenuse
                local h = math.sqrt( ox^2+oy^2)
                -- get hypotenuse extension
                local oh = pc*tg+pc*h
                -- directions
                local dx, dy = 1,1
                if icx<cx then dx=-dx end
                if icy<cy then dy=-dy end
                if icy==cy then dy=0 end
                if ang>=math.pi then fnum=-1 end
                if ang<math.pi then fnum=1 end
                -- calc new x & y
                local nx = oh * math.cos(ang) * dx
                local ny = oh * math.sin(ang) * dy
                
                -- move!
                
                ic:rotate(pc*math.pi*animations[i]*0.04, 0, 0, 1)
ic:rotate(pc*math.pi*a2[i]*0.04, 0, 1, 0)
ic:rotate(pc*math.pi*a3[i]*0.04, 1, 0, 0)
                -- rand = rand - did
                -- if pc>0.6 then
                        -- ic.alpha = 1-pc
                -- end

    end
end

