local function hop(view, percent,height,offset)
    local oldp = percent
    if percent < 0 then percent = -percent end

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        local mult = 1
        if (i % #view.subviews/i < i) then mult = -i end

        v:translate(mult*offset/25, mult*percent*height/25, 0)
	view:translate(offset/3*percent,0)
    end
end

return function(page, offset, width, height)
    local percent = offset/width
    hop(page, percent, height ,offset)
end