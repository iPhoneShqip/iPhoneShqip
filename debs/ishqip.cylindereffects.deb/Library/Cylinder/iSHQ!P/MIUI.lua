local function row(view, percent, width)

    local i = 0
	
	while true do
		i = i + 1
		local v = view[i]
		if v == nil then break end

		if i < 6 then
			v:translate(width*percent/100, 0, 0)
			
		elseif i < 11 and percent > 0.05 then
			v:translate(width*(percent+5)/100, 0, 0)
			
		elseif i < 16 and percent > 0.1 then
			v:translate(width*(percent+10)/100, 0, 0)
			
		elseif i < 21 and percent > 0.15 then
			v:translate(width*(percent+15)/100, 0, 0)
		
		elseif i < 26 and percent > 0.2 then
			v:translate(width*(percent+20)/100, 0, 0)
			
		elseif i < 31 and percent > 0.25 then
			v:translate(width*(percent+25)/100, 0, 0)
			
		elseif i < 36 and percent > 0.3 then
			v:translate(width*(percent+30)/100, 0, 0)
			
		else
			v:translate(width*percent, 0, 0)
		end
	end
end

return function(page, offset, width, height)
	local percent = offset/width
	if percent < 0 then percent = -percent end
	
	row(page, percent, width)
	
end