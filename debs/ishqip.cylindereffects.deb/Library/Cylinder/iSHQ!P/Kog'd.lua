return function(page, offset, screen_width, screen_height)
    local percent = offset/page.width
	local dem=offset*page.height
	for i, icon in subviews(page) do
	icon:rotate(percent-dem+33,0,0,1)
	end
end