return function(page, offset, width, height)
  percent = offset/width
  page:translate(offset, 0, 0)
  page:rotate(percent*math.pi, 0, -1, 0)
  page.alpha = 1 - math.abs(percent*2)
end