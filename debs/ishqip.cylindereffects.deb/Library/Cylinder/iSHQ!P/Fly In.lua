local fade = dofile("include/fade.lua")

local M_PI = 3.14159265

return function(page, offset, width, height)

	local percent = offset/width
	page:translate(-offset, offset, offset)
	fade(page, -percent)

end