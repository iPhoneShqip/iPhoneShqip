local fade = dofile("include/fade.lua")



return function(page, offset, screen_width, screen_height)



	local percent = offset/page.width

	page:translate(offset, offset, offset)

	fade(page, percent)



end