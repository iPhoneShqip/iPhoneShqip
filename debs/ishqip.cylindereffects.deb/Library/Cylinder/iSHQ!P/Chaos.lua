local random = {}
local random_angle = {}

return function(page, offset, screen_width, screen_height)
    local percent = offset/page.width
    local mid_height = screen_height/2.5

    if offset == 0 then
      for i=1, 24 do
        random[i] = math.random(1, 300)
        random_angle[i] = math.random(1, 628)
        --print(random[i])
      end
      --
    end

    page:translate(-offset/10)

    for i, icon in subviews(page) do
      local k = 32
      local k2 = 1.5
      if i % 4 == 1 then
        k = 1.5
        k2 = 32
      elseif i % 4 == 2 then
        k = 2
        k2 = 6
      elseif i % 4 == 3 then
        k = 6
        k2 = 2
      end

      if percent > 0 then
        icon:translate(offset/k, percent* (mid_height - icon.y + random[i] - 150),0) 
      else 
        icon:translate(offset/k2, -percent* (mid_height - icon.y + random[i] - 150),0)
      end

      icon:rotate(percent * (random_angle[i] / 100))
      --fade(icon, percent)

    end

end