local M_PI = 3.14159265

local function slide(view, percent, height, width,offset)
    local oldp = percent

    local i = 0
    while true do
        i = i + 1
        local v = view[i]
        if v == nil then break end

        v:translate(-offset*i*.5,0,0)
        view:translate(offset/i^i,0,0)
    end
end
local function fade(page,percent)
        local p = percent
        if percent < 0 then p = -p end
        page.alpha = 1 - p
end
return function(page, offset, width, height)
    local percent = offset/width
    slide(page, percent, height, width,offset)
    fade(page,percent)
end